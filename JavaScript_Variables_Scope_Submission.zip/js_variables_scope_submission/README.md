# JavaScript Practice: Variables & Scope (Predict the Output)

Each question file begins with a prediction comment, as requested. Run files independently with Node.js:
`node questions/question_01.js`

For Question 8, run each outside-scope check independently because an uncaught ReferenceError stops the current script:
- `node -e "{ var m=1; let n=2; const o=3; } console.log(m)"`
- `node -e "{ var m=1; let n=2; const o=3; } console.log(n)"`
- `node -e "{ var m=1; let n=2; const o=3; } console.log(o)`

See `JavaScript_Variables_and_Scope.docx` for explanations and console-output captures.
