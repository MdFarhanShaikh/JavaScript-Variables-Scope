// Prediction: SyntaxError; no output
let subject = "HTML";
let subject = "CSS";
console.log(subject);
