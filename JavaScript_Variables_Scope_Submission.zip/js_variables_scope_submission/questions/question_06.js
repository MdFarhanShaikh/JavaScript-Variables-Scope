// Prediction: DBMS
var course = "FSD";
var course = "DBMS";
console.log(course);
