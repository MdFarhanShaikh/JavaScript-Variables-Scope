// Prediction: TypeError; no value is logged
const pi = 3.14;
pi = 3.14159;
console.log(pi);
