// Prediction for separate checks: m → 1; n → ReferenceError; o → ReferenceError
{
  var m = 1;
  let n = 2;
  const o = 3;
}
// Run each line separately after the block:
console.log(m);
console.log(n);
console.log(o);
