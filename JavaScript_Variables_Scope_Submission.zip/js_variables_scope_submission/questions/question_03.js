// Prediction: undefined, then 5
console.log(p);
var p = 5;
console.log(p);
