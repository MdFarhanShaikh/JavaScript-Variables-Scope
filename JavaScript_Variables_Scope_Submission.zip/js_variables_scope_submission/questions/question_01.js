// Prediction: 20
let a = 10;
a = 20;
console.log(a);
