// Prediction: ReferenceError; no value is logged
let msg = "outer";
{
  console.log(msg);
  let msg = "inner";
}
