// Prediction: ReferenceError
console.log(q);
let q = 10;
